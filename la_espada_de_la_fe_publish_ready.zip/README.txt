La Espada de la Fe

Static site. No build step required.
Publish directory: ./
